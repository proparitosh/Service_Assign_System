from django.shortcuts import render, redirect, get_object_or_404
from .models import Technician, ServiceRequest
from .forms import ServiceRequestForm

# Create your views here.

# Home view: list of service requests
def home(request):
    requests = ServiceRequest.objects.all()
    return render(request, 'allocation/home.html', {'requests': requests})

# View for users to request a service
def request_service(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST)
        if form.is_valid():
            form.save()  # Save request to DB
            return redirect('home')  # Go back to homepage
    else:
        form = ServiceRequestForm()
    return render(request, 'allocation/request_service.html', {'form': form})


# Admin/assign technician manually (optional, simplified)
def assign_technician(request, request_id):
    service_request = get_object_or_404(ServiceRequest, id=request_id)
    technicians = Technician.objects.all()

    if request.method == 'POST':
        technician_id = request.POST.get('technician_id')
        if technician_id:
            technician = get_object_or_404(Technician, id=technician_id)
            service_request.assigned_technician = technician
            service_request.status = 'Assigned By Customer'  # or whatever status you want
            service_request.save()
            return redirect('home')  # redirect to home or another page
        else:
            # Handle case if no technician selected
            error_message = "Please select a technician."
            return render(request, 'allocation/assign.html', {
                'service_request': service_request,
                'technicians': technicians,
                'error_message': error_message
            })

    return render(request, 'allocation/assign.html', {
        'service_request': service_request,
        'technicians': technicians
    })