from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('request/', views.request_service, name='request_service'),
    path('assign/<int:request_id>/', views.assign_technician, name='assign_technician'),
]
