from django.contrib import admin

# Register your models here.
from .models import Technician, ServiceRequest

admin.site.register(Technician)  # Enables Technician model in admin
admin.site.register(ServiceRequest)  # Enables ServiceRequest model in admin