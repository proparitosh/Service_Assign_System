from django import forms
from .models import ServiceRequest

# Form to let users request service
class ServiceRequestForm(forms.ModelForm):
    class Meta:
        model = ServiceRequest
        fields = ['customer_name', 'contact_info', 'issue_description', 'required_skill']
