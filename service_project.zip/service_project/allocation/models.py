from django.db import models

class Technician(models.Model):
    name = models.CharField(max_length=100)  # Technician's name
    skills = models.CharField(max_length=200)  # Skills like 'plumbing, electrical'
    is_available = models.BooleanField(default=True)  # Availability status

    def __str__(self):
        return self.name  # Used for displaying in admin dropdowns

class ServiceRequest(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed'),
    ]

    customer_name = models.CharField(max_length=100)  # Who is requesting the service
    contact_info = models.CharField(max_length=100)  # Phone/email
    issue_description = models.TextField()  # What is the issue
    required_skill = models.CharField(max_length=100)  # e.g. plumbing
    assigned_technician = models.ForeignKey(
        Technician, null=True, blank=True, on_delete=models.SET_NULL
    )  # Links to Technician (can be blank initially)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')  # Track progress
    created_at = models.DateTimeField(auto_now_add=True)  # Automatically store when request is made

    def __str__(self):
        return f"{self.customer_name} - {self.issue_description[:20]}"
